import telebot
from keep_alive import keep_alive

# ใส่ Token ของบอทที่ได้รับจาก BotFather
API_TOKEN = '7122130151:AAHf_DyP6kNl-jfz4rB5fUAbHmcqAZ2_iF4'

# สร้างบอท
bot = telebot.TeleBot(API_TOKEN)

# เมื่อมีคนพิมพ์ '/เริ่ม'
@bot.message_handler(commands=['เริ่ม'])
def send_start(message):
    bot.reply_to(message, "✅")

# เมื่อมีคนพิมพ์ '/คำสั่ง'
@bot.message_handler(commands=['คำสั่ง'])
def send_commands(message):
    commands = "🔶 คำสั่งทั้งหมด 🔶\n1). 💊 /แบน\n2). 💊 /เพิ่มผู้ใช้\n3). 💊 /สแปม\n4). 💊 /กฎ"
    bot.reply_to(message, commands)

# เมื่อมีคนพิมพ์ '/แบน'
@bot.message_handler(commands=['แบน'])
def ban_user(message):
    bot.reply_to(message, "ยังไม่ทำ")

# เมื่อมีคนพิมพ์ '/เพิ่มผู้ใช้'
@bot.message_handler(commands=['เพิ่มผู้ใช้'])
def add_user(message):
    bot.reply_to(message, "ยังไม่ทำ")

# เมื่อมีคนพิมพ์ '/คิดไม่ออก'
@bot.message_handler(commands=['คิดไม่ออก'])
def unknown(message):
    bot.reply_to(message, "ยังไม่ทำ")

# เมื่อมีคนพิมพ์ '/' หรือคำสั่งไม่ระบุ
@bot.message_handler(commands=[''])
def unknown_command(message):
    bot.reply_to(message, "🟥 ไม่พบคำสั่งในรายการ 🟥")

# เมื่อมีคนพิมพ์ '/กฎ'
@bot.message_handler(commands=['กฎ'])
def rules(message):
    group_rules = "🚫 กฎในกลุ่มของเรา 🚫\n1) ⚠️ ห้ามเก\n2) ⚠️ ห้ามทะเลาะกันไม่งั้นบินคู่\n3) ⚠️ ห้ามเพิ่มphim phim maxเข้ากลุ่ม\n4) ⚠️ ห้ามสแปมไม่งั้นบิน\n5) ⚠️ คิดไม่ออก"
    bot.reply_to(message, group_rules)

# เมื่อมีคนเข้ากลุม
@bot.message_handler(func=lambda message: True, content_types=['new_chat_members'])
def welcome_new_member(message):
    new_members = message.new_chat_members
    for member in new_members:
        bot.reply_to(message, f'♨️สวัสดี {member.first_name} ยินดีต้อนรับสู่กลุ่มของเรา เข้ามาแล้วอย่าลืม /กฎ แล้วปฏิบัติตามกฎด้วยล่ะ😀!')

# เมื่อมีคนพิมพ์ '/สแปม'
@bot.message_handler(commands=['สแปม'])
def handle_spam(message):
    # แยกข้อความและจำนวนการส่งจากข้อความที่ผู้ใช้พิมพ์
    try:
        text_and_count = message.text.split(maxsplit=1)[1]
        text, count = text_and_count.split(maxsplit=1)
        count = int(count)
        if count > 500:
            bot.reply_to(message, '⚠️การส่งข้อความจำกัดที่500ครั้งเท่านั้น⚠️')
            return
    except IndexError:
        bot.reply_to(message, '⚠️ คุณลืมใส่ข้อความและจำนวนการส่ง ⚠️')
        return
    except ValueError:
        bot.reply_to(message, '⚠️ คุณลืมใส่จำนวนการส่ง ⚠️')
        return

    # ส่งข้อความตามจำนวนที่กำหนด
    for _ in range(min(count, 500)):
        bot.reply_to(message, text)

# รันบอท
keep_alive()
bot.polling()
